
%% Correlating QPP fine summary maps with its corresponding gradient
%%
clear; clc; close all; p1='../'; isd=1; 
irf=[1 1 2]; % indices of "rf" as seed for correlation map within QPP
p2p=dir([p1 'Params_*.mat']); p2p=[p1 p2p.name];
load(p2p,'p2V','nP','p2u','ivx','nvx','PLc','nVX','d2SAcft'); 
p2V=[p1 p2V]; p2u=[p1 p2u]; addpath(genpath(p2u)); 
load(p2V,'QPPv_te','QPPv','QPPv_io','QPPv_rf');
load('myGrds.mat','GD','nGD'); nrgn=length(nGD); rgnr=find(~isnan(nGD))'; 
GPR=nan(nrgn,max(nGD)); % which gradient to asses vs QPP per region
GPR(1,:)=[1 3 2]; GPR(2,1:2)=1:2; GPR(4,1:2)=1; GPR(7,1:2)=1;

%%
cTG=nan(nrgn,nP,2); pTG=cTG; CWT=nan(nvx,nP,'single');
for ip=1:nP
    tp=QPPv_te(:,1,ip,isd); ixp=find(isnan(tp));
    
    io=QPPv_io{ip,isd};
    T=QPPv{ip,isd}(io,PLc)'; rf=QPPv_rf(PLc,irf(ip),ip,isd);
    cwt=corr(T,rf); CWT(io,ip)=cwt; 
    
    for irgn=rgnr
        ig=GPR(irgn,ip);
        if ~isnan(ig)
            gd=GD{irgn}(ivx,ig); ix=unique([ixp;find(isnan(gd))]); 
            t=tp; t(ix)=[]; g=gd; g(ix)=[];
            [cTG(irgn,ip,1),pTG(irgn,ip,1)]=corr(t,g);
            
            g=gd(io); ix=find(isnan(g)); 
            c=cwt; c(ix)=[]; g(ix)=[];
            [cTG(irgn,ip,2),pTG(irgn,ip,2)]=corr(c,g);
        end
    end
end
cTG=round(cTG,2); pTG=round(pTG,2);

%% 
M=nan(nVX,nP); M(ivx,:)=CWT;
e=ft_read_cifti('empty.dtseries.nii');
e.dtseries=M; e.time=1:nP; e.hdr.dim(6)=nP; 
ft_write_cifti([d2SAcft 'Corr_within_QPP'],e,'parameter','dtseries');
