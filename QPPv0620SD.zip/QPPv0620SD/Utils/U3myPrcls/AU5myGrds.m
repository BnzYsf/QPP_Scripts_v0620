
%% Gradients: reading various files & saving into cifti format
%%
clear; clc;
load('../myHCPcft.mat','nrgn','sc','nVX','nVXC'); 
GD=cell(nrgn,1); sc=[{[]};sc];
addpath '../' '../NIfTI_20140122/' '../cifti-matlab-master/' './VarGrads';

e=ft_read_cifti('../empty.dtseries.nii'); 
ps=e.pos-diag(e.transform(1:3,1:3))';
st=e.brainstructure;

%% Cerebral cortex (Margulies et al 2016)
irgn=1; nG=3; 
f2r='hcp.gradients.dscalar.nii';
f2s='AG1_Cerebrum_Margulies';

g=ft_read_cifti(f2r);
A=nan(nVX,nG,'single');
for i=1:nG, eval(['A(1:nVXC,i)=g.gradient_' num2str(i) '(1:nVXC);']); end
GD{irgn}=A;

e.dtseries=A; e.time=1:nG; e.hdr.dim(6)=nG; 
ft_write_cifti(f2s,e,'parameter','dtseries');

%% Cerebellum (Guell et al 2018)
irgn=2; nG=2; 
ns='result_cerebellumonly_gradient'; ne='.dscalar.nii';
f2r={[ns '1' ne],[ns '2' ne]};
f2s='AG2_Cerebellum_Guell';
J=find(st==10|st==11); 
ixf=[3526,12389]; J(ixf)=[];

A=nan(nVX,nG,'single');
for i=1:nG
    g=ft_read_cifti(f2r{i});
    s=g.brainstructure;
    A(J,i)=g.dscalar(s==2|s==3);   
end; clear g s J
GD{irgn}=A;

% e.dtseries=A; e.time=1:nG; e.hdr.dim(6)=nG; 
% ft_write_cifti(f2s,e,'parameter','dtseries');

% g=ft_read_cifti(f2r{2});
% s=g.brainstructure; I=find(s==2|s==3); P=g.pos(I,:);
% P0=e.pos(st==10|st==11,:);
% Pc=intersect(P,P0,'rows');
% dr=2;
% a=[P; zeros(dr,3)]; 
% for j=1:3, ix(j)=find(a(:,j)-P0(:,j),1); end
% ix=min(ix); ixf(1)=ix; P02=P0; P02(ix,:)=[];
% a=[P; zeros(dr-1,3)]; 
% for j=1:3, ix(j)=find(a(:,j)-P02(:,j),1); end
% ix=min(ix); ixf(2)=ix+1; P02(ix,:)=[];
% P03=P0; P03(ixf,:)=[];
% d=P-P03; length(find(d))
% % ixf=[3526,12389];

%% Hippocampus (Vos De Wael et al 2018)
irgn=4; nG=2;
ns='hippocampus_gradient'; ne='.nii.gz'; 
f2r={[ns '1' ne],[ns '2' ne]};
f2s='AG4_Hippocampus_VosDeWael';

A=nan(nVX,nG,'single');
for i=1:nG
    g=load_nii(f2r{i}); g1=g.img;
    og=g.hdr.hist.originator(1:3); dg=g.hdr.dime.pixdim(2);
    clear I; [I(:,1),I(:,2),I(:,3)]=ind2sub(size(g1),find(g1));
    P=(I-og)*dg; P=round(P);
    [~,iP,ips]=intersect(P,ps,'rows');
    s=st(ips); u=unique(s); 
    [~,iu,~]=intersect(u,sc{irgn}); u(iu)=[];
    ix=[]; for j=1:length(u), ix=[ix; find(s==u(j))]; end
    ips(ix)=[]; iP(ix)=[];
    J=sub2ind(size(g1),I(iP,1),I(iP,2),I(iP,3));
    A(ips,i)=g1(J); 
end; clear g g1 og dg I P iP ips s u iu ix J
GD{irgn}=A;

% e.dtseries=A; e.time=1:nG; e.hdr.dim(6)=nG; 
% ft_write_cifti(f2s,e,'parameter','dtseries');

%% Striatum (Marquand et al 2017)
irgn=7;
ns='group.'; ne='h.striatum.evec.0.nii.gz'; % 0:FCG 1:Fig2-FC(Str&Crtx)
f2r={[ns 'l' ne],[ns 'r' ne]};
f2s='AG7_Striatum_Marquand';

A=nan(nVX,1,'single');
for i=1:2
    g=load_nii(f2r{i}); g1=g.img;  
    og=g.hdr.hist.originator(1:3); dg=g.hdr.dime.pixdim(2);
    clear I; [I(:,1),I(:,2),I(:,3)]=ind2sub(size(g1),find(g1));
    P=(I-og)*dg;
    [~,iP,ips]=intersect(P,ps,'rows');
    s=st(ips); u=unique(s);
    [~,iu,~]=intersect(u,sc{irgn}); u(iu)=[];
    ix=[]; for j=1:length(u), ix=[ix; find(s==u(j))]; end
    ips(ix)=[]; iP(ix)=[];
    J=sub2ind(size(g1),I(iP,1),I(iP,2),I(iP,3));
    A(ips)=g1(J);
end; clear g g1 og dg I P iP ips s u iu ix J
GD{irgn}=A;

% e.dtseries=A; e.time=1; e.hdr.dim(6)=1; 
% ft_write_cifti(f2s,e,'parameter','dtseries');

%%
nGD=[3 2 nan 2 nan nan 1]';
save('../myGrds.mat','GD','nGD');
